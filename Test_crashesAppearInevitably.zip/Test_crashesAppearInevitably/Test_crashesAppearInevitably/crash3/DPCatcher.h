//
//  DPCatcher.h
//  Test_crashAppearInevitably
//
//  Created by 罗富中 on 2017/12/19.
//  Copyright © 2017年 罗富中. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DPCatcher : NSObject
@property(nonatomic,assign) Class originalClass;
@end
