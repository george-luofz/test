//
//  DPISARegeister.h
//  Test_crashAppearInevitably
//
//  Created by 罗富中 on 2017/12/19.
//  Copyright © 2017年 罗富中. All rights reserved.
//



#import <Foundation/Foundation.h>
void init(void);
@interface DPISARegeister:NSObject
@end
