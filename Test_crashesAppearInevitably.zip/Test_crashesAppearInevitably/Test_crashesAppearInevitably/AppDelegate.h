//
//  AppDelegate.h
//  Test_crashesAppearInevitably
//
//  Created by 罗富中 on 2017/12/20.
//  Copyright © 2017年 罗富中. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

